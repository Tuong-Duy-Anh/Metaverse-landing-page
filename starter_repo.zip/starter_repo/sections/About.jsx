'use client';

const About = () => (
  <section>
    About section
  </section>
);

export default About;
